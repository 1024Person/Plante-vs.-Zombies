#include "Cimage.h"

Cimage::Cimage()
{
	//���뱳��ͼƬ
	loadimage(&BK, "bk1.jpg");
	////���뿪ʼͼƬ
	//extern  const short w;
	//extern  const short h;
	loadimage(&STRAT, "STRAT.png",981,595);//����981��������������Ļ�Ŀ���595��������������Ļ�ĸߣ���Ϊ�����������w��h�ò�������ֻ����ֱ������
	//����ʤ��ͼƬ
	loadimage(&ima_vctory1, "VCTORY1.png");

	loadimage(&ima_vctory2, "VCTORY2.png");

	//������������ͼƬ
	loadimage(&BANK, "BANK.jpg");
	//�������ӿ�Ƭ
	//�������ֿ�Ƭ
	loadimage(&CARD_S, "CARD_S.jpg");
	//����̫������Ƭ
	loadimage(&CARD_SUN_FLOWER,"CARD_sunFlower.png",CARD_S.getwidth(),CARD_S.getheight());
	//���뽩ʬͼƬ
	//�ڵײ�ͼ
	loadimage(&ima_enemy1[0], "enemy1_1.jpg", 71, 97);
	loadimage(&ima_enemy1[1], "enemy2_1.jpg", 71, 97);
	loadimage(&ima_enemy1[2], "enemy3_1.jpg", 71, 97);
	loadimage(&ima_enemy1[3], "enemy4_1.jpg", 71, 97);
	loadimage(&ima_enemy1[4], "enemy5_1.jpg", 71, 97);
	loadimage(&ima_enemy1[5], "enemy6_1.jpg", 71, 97);
	loadimage(&ima_enemy1[6], "enemy7_1.jpg", 71, 97);
	loadimage(&ima_enemy1[7], "enemy8_1.jpg", 71, 97);
	loadimage(&ima_enemy1[8], "enemy9_1.jpg", 71, 97);
	loadimage(&ima_enemy1[9], "enemy10_1.jpg", 71, 97);
	loadimage(&ima_enemy1[10], "enemy11_1.jpg", 71, 97);
	loadimage(&ima_enemy1[11], "enemy12_1.jpg", 71, 97);
	loadimage(&ima_enemy1[12], "enemy13_1.jpg", 71, 97);
	loadimage(&ima_enemy1[13], "enemy14_1.jpg", 71, 97);
	loadimage(&ima_enemy1[14], "enemy15_1.jpg", 71, 97);
	loadimage(&ima_enemy1[15], "enemy16_1.jpg", 71, 97);
	loadimage(&ima_enemy1[16], "enemy17_1.jpg", 71, 97);
	loadimage(&ima_enemy1[17], "enemy18_1.jpg", 71, 97);
	loadimage(&ima_enemy1[18], "enemy19_1.jpg", 71, 97);
	loadimage(&ima_enemy1[19], "enemy20_1.jpg", 71, 97);
	loadimage(&ima_enemy1[20], "enemy21_1.jpg", 71, 97);
	loadimage(&ima_enemy1[21], "enemy22_1.jpg", 71, 97);
	//��ʬ�׵׺�ͼ
	loadimage(&ima_enemy2[0], "enemy1_2.jpg", 71, 97);
	loadimage(&ima_enemy2[1], "enemy2_2.jpg", 71, 97);
	loadimage(&ima_enemy2[2], "enemy3_2.jpg", 71, 97);
	loadimage(&ima_enemy2[3], "enemy4_2.jpg", 71, 97);
	loadimage(&ima_enemy2[4], "enemy5_2.jpg", 71, 97);
	loadimage(&ima_enemy2[5], "enemy6_2.jpg", 71, 97);
	loadimage(&ima_enemy2[6], "enemy7_2.jpg", 71, 97);
	loadimage(&ima_enemy2[7], "enemy8_2.jpg", 71, 97);
	loadimage(&ima_enemy2[8], "enemy9_2.jpg", 71, 97);
	loadimage(&ima_enemy2[9], "enemy10_2.jpg", 71, 97);
	loadimage(&ima_enemy2[10], "enemy11_2.jpg", 71, 97);
	loadimage(&ima_enemy2[11], "enemy12_2.jpg", 71, 97);
	loadimage(&ima_enemy2[12], "enemy13_2.jpg", 71, 97);
	loadimage(&ima_enemy2[13], "enemy14_2.jpg", 71, 97);
	loadimage(&ima_enemy2[14], "enemy15_2.jpg", 71, 97);
	loadimage(&ima_enemy2[15], "enemy16_2.jpg", 71, 97);
	loadimage(&ima_enemy2[16], "enemy17_2.jpg", 71, 97);
	loadimage(&ima_enemy2[17], "enemy18_2.jpg", 71, 97);
	loadimage(&ima_enemy2[18], "enemy19_2.jpg", 71, 97);
	loadimage(&ima_enemy2[19], "enemy20_2.jpg", 71, 97);
	loadimage(&ima_enemy2[20], "enemy21_2.jpg", 71, 97);
	loadimage(&ima_enemy2[21], "enemy22_2.jpg", 71, 97);

	//��������ͼƬ//�ڵײ�ͼ
	loadimage(&ima_shooter1[0], "shooter1_1.jpg", 71, 97);
	loadimage(&ima_shooter1[1], "shooter2_1.jpg", 71, 97);
	loadimage(&ima_shooter1[2], "shooter3_1.jpg", 71, 97);
	loadimage(&ima_shooter1[3], "shooter4_1.jpg", 71, 97);
	loadimage(&ima_shooter1[4], "shooter5_1.jpg", 71, 97);
	loadimage(&ima_shooter1[5], "shooter6_1.jpg", 71, 97);
	loadimage(&ima_shooter1[6], "shooter7_1.jpg", 71, 97);
	loadimage(&ima_shooter1[7], "shooter8_1.jpg", 71, 97);
	loadimage(&ima_shooter1[8], "shooter9_1.jpg", 71, 97);
	loadimage(&ima_shooter1[9], "shooter10_1.jpg", 71, 97);
	//�׵׺�ͼ
	loadimage(&ima_shooter2[0], "shooter1_2.jpg", 71, 97);
	loadimage(&ima_shooter2[1], "shooter2_2.jpg", 71, 97);
	loadimage(&ima_shooter2[2], "shooter3_2.jpg", 71, 97);
	loadimage(&ima_shooter2[3], "shooter4_2.jpg", 71, 97);
	loadimage(&ima_shooter2[4], "shooter5_2.jpg", 71, 97);
	loadimage(&ima_shooter2[5], "shooter6_2.jpg", 71, 97);
	loadimage(&ima_shooter2[6], "shooter7_2.jpg", 71, 97);
	loadimage(&ima_shooter2[7], "shooter8_2.jpg", 71, 97);
	loadimage(&ima_shooter2[8], "shooter9_2.jpg", 71, 97);
	loadimage(&ima_shooter2[9], "shooter10_2.jpg", 71, 97);

	//�����ӵ�ͼƬ
	loadimage(&ima_buttle1, "buttle1.jpg", 20, 20);
	loadimage(&ima_buttle2, "buttle2.jpg", 20, 20);

	//����̫����ͼƬ//���غڵײ�ͼ
	loadimage(&ima_sunFlower1[0], "sun_flower1_1.jpg", 71, 97);
	loadimage(&ima_sunFlower1[1], "sun_flower2_1.jpg", 71, 97);
	loadimage(&ima_sunFlower1[2], "sun_flower3_1.jpg", 71, 97);
	loadimage(&ima_sunFlower1[3], "sun_flower4_1.jpg", 71, 97);
	loadimage(&ima_sunFlower1[4], "sun_flower5_1.jpg", 71, 97);
	loadimage(&ima_sunFlower1[5], "sun_flower6_1.jpg", 71, 97);
	loadimage(&ima_sunFlower1[6], "sun_flower7_1.jpg", 71, 97);
	loadimage(&ima_sunFlower1[7], "sun_flower8_1.jpg", 71, 97);
	loadimage(&ima_sunFlower1[8], "sun_flower9_1.jpg", 71, 97);
	//���ذ׵׺�ͼ
	loadimage(&ima_sunFlower2[0], "sun_flower1_2.jpg", 71, 97);
	loadimage(&ima_sunFlower2[1], "sun_flower2_2.jpg", 71, 97);
	loadimage(&ima_sunFlower2[2], "sun_flower3_2.jpg", 71, 97);
	loadimage(&ima_sunFlower2[3], "sun_flower4_2.jpg", 71, 97);
	loadimage(&ima_sunFlower2[4], "sun_flower5_2.jpg", 71, 97);
	loadimage(&ima_sunFlower2[5], "sun_flower6_2.jpg", 71, 97);
	loadimage(&ima_sunFlower2[6], "sun_flower7_2.jpg", 71, 97);
	loadimage(&ima_sunFlower2[7], "sun_flower8_2.jpg", 71, 97);
	loadimage(&ima_sunFlower2[8], "sun_flower9_2.jpg", 71, 97);
	//����̫��ͼƬ
	loadimage(&ima_sun1, "sun1.jpg",60,60);
	loadimage(&ima_sun2, "sun2.jpg", 60, 60);

}

//���ظ���ͼƬ�ĵ�ַ
const IMAGE* Cimage::get_enemy1(short num)
{
	
	return &ima_enemy1[num];
}
const IMAGE* Cimage::get_enemy2(short num)
{

	return &ima_enemy2[num];
}
const IMAGE* Cimage::get_bk()
{
	
	return &BK;
}
const IMAGE* Cimage::get_shooter1(short num)
{
	return &ima_shooter1[num];
}
const IMAGE* Cimage::get_shooter2(short num)
{
	return &ima_shooter2[num];
}
const IMAGE* Cimage::get_buttle1()
{
	return &ima_buttle1;
}
const IMAGE* Cimage::get_buttle2()
{
	return &ima_buttle2;
}
const IMAGE* Cimage::get_BANK()
{
	return &BANK;
}
const IMAGE* Cimage::get_CARD_S()
{
	return &CARD_S;
}
const IMAGE* Cimage::get_sun_flower1(short num)
{
	return &ima_sunFlower1[num];
}
const IMAGE* Cimage::get_sun_flower2(short num)
{
	return &ima_sunFlower2[num];
}
const IMAGE* Cimage::get_CardSunFlower()
{
	return &CARD_SUN_FLOWER;
}
const IMAGE* Cimage::get_sun1()
{
	return &ima_sun1;
}
const IMAGE* Cimage::get_sun2()
{
	return &ima_sun2;
}
const IMAGE* Cimage::get_START()
{
	return &STRAT;
}
const IMAGE* Cimage::get_vctory1()
{
	return &ima_vctory1;
}
const IMAGE* Cimage::get_vctory2()
{
	return &ima_vctory2;
}